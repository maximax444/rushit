$(document).on({
    mouseenter: function () {
        $('.main__prod').not($(this)).addClass('hide');
    },
    mouseleave: function () {
        $('.main__prod').not($(this)).removeClass('hide');
    }
}, '.main__prod');
// if ($(window).width() > 1199) {
//     new fullpage('.fullpage', {
//         horizontal: true,
//         onLeave: function (link, index) {
//             console.log(index);

//             $(link.item).addClass('notNormal');
//             $(index.item).css('z-index', '999');
//             $(link.item).css('z-index', '2');
//             if ($(index.item).hasClass('notNormal')) {
//                 $(index.item).removeClass('notNormal');
//             }
//             if (index.index == 2) {
//                 let counter = document.querySelectorAll('.counter');
//                 let limit = 0;
//                 if (limit == counter.length) { return; }

//                 for (let i = 0; i < counter.length; i++) {
//                     let pos = counter[i].getBoundingClientRect().top; //Позиция блока, считая сверху окна
//                     if (counter[i].dataset.stop === "0") {
//                         counter[i].dataset.stop = 1; // Останавливаем перезапуск счета в этом блоке
//                         let x = 0;
//                         limit++; // Счетчик будет запущен, увеличиваем переменную на 1
//                         let int = setInterval(function () {
//                             // Раз в 60 миллисекунд будет прибавляться 50-я часть нужного числа
//                             x = x + Math.ceil(counter[i].dataset.to / 25);
//                             counter[i].innerText = x.toLocaleString();
//                             if (x > counter[i].dataset.to) {
//                                 //Как только досчитали - стираем интервал.
//                                 counter[i].innerText = (counter[i].dataset.to / 1).toLocaleString();
//                                 clearInterval(int);
//                             }
//                         }, 50);
//                     }
//                 }
//             }


//             console.log(index.index);
//         }
//     });
// }

var inputs = document.querySelectorAll('.file input');
Array.prototype.forEach.call(inputs, function (input) {
    var label = input.nextElementSibling,
        labelVal = label.innerHTML;
    input.addEventListener('change', function (e) {
        var fileName = '';
        if (this.files && this.files.length > 1)
            fileName = (this.getAttribute('data-multiple-caption') || '').replace('{count}', this.files.length);
        else
            fileName = e.target.value.split('\\').pop();
        if (fileName)
            label.querySelector('span').innerHTML = fileName;
        else
            label.innerHTML = labelVal;
    });
});

$('.home-contacts__rekv').on('click', function (e) {
    e.preventDefault();
    $('.overlay-rekv').addClass('overlay-active');
});
$('.header__call, .main__prod').on('click', function (e) {
    e.preventDefault();
    $('.overlay-call').addClass('overlay-active');
});
$('.home-contacts__map').on('click', function (e) {
    e.preventDefault();
    $('.overlay-ya').addClass('overlay-active');
});


$('.overlay-rekv').on('click', function (e) {
    if (!(($(e.target).parents('.popup-wrap').length) || ($(e.target).hasClass('popup-wrap')))) {
        $('.overlay-rekv').removeClass('overlay-active');
    }
});
$('.overlay-call').on('click', function (e) {
    if (!(($(e.target).parents('.popup-wrap').length) || ($(e.target).hasClass('popup-wrap')))) {
        $('.overlay-call').removeClass('overlay-active');
    }
});
$('.overlay-ya').on('click', function (e) {
    if (!(($(e.target).parents('.popup-wrap').length) || ($(e.target).hasClass('popup-wrap')))) {
        $('.overlay-ya').removeClass('overlay-active');
    }
});

$('.popup-close').on('click', function (e) {
    $(this).closest('.overlay').removeClass('overlay-active');
});

if ($(window).width() <= 575) {
    var items = $('.home-features__el'),
        per = 5,
        i = 1,
        total = 0;
    $('.home-features__more').on('click', function (e) {
        e.preventDefault();
        total = per * (i++);
        items.slice(0, total).css('display', 'block');
        $(this)[total >= items.length ? 'hide' : 'show']();
    }).click();
}

function sendFormTo(form) {
    let formData = new FormData(form);
    let xhr = new XMLHttpRequest();
    var th = form;


    // Валидация
    var novalidInputs = th.querySelectorAll('[novalid]');
    for (let i = 0; i < novalidInputs.length; i++) {
        novalidInputs[i].removeAttribute("novalid");
    }

    var novalidInputs = 0;
    for (var key of formData.keys()) {
        if (formData.get(key) == '' || formData.get(key) == null) {
            if (key == 'name') {
                form.querySelector('input[name=' + key + ']').setAttribute("novalid", "true");
                novalidInputs++
            }
            if (key == 'phone') {
                form.querySelector('input[name=' + key + ']').setAttribute("novalid", "true");
                novalidInputs++
            }
        }
    }

    if (novalidInputs > 0) {
        return false;
    }

    xhr.open("POST", "../mail/mail.php");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                form.reset();
            }
        }
    };
    xhr.send(formData);
}


document.querySelectorAll('form').forEach(link => {
    link.addEventListener('submit', function (e) {
        e.preventDefault();
        sendFormTo(this);
    });
});